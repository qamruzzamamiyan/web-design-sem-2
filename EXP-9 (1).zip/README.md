# EXP-9 React Project

## Features
- Registration Form
- useState for form handling
- Validation for inputs
- Error message display
- Success message display
- API Fetching using useEffect
- Loading state handling

## Run the Project

### Install dependencies
npm install

### Start project
npm start
